Author: Alvin Sng  http://www.alvinsng.com
Licenese: GPL 
Website: cloudstorage.souceforge.net
Last Updated: 3/31/2011
Version 3.2

Thank you for trying out Cloud Storage, this is still a beta and is still buggy.
It is constanly updated every so often with new features and bug fixes.
To install simply drag this folder into a web accessible directory. 
Also make this entire directory CHMOD 777 recursivesly for an easy install.
There is a easy install GUI that will guide you though. 
After that you should be on your way to using Cloud Storage.