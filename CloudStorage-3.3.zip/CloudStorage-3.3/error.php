<?php
$error_id=$_GET['id'];
if(!is_numeric($error_id)){
	$error_id=0;
}

$error=null;
$error[0]=array("Invalid Error","The page you are trying to reach is unavailable");
$error[1]=array("tmp/ directory unaccessible","Please delete the <b>tmp/</b> directory in the root of the website to fix this issue");
$error[2]=array("tmp/ directory has insufficient permissions","Please allow the <b>tmp/</b> directory in the root of the website to have permissions to create directories chmod 777.");
$error[3]=array("Database Down","The site's database is currently unavailable");
?>
<h2><?php echo $error[$error_id][0];?></h2>
<p><?php echo $error[$error_id][1];?></p>