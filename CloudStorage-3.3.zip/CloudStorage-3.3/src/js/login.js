function display_message(msg,type){
	if(type==null){
		type="error";
	}
	if(type=="error"){
		var icon = "cancel";
	}
	else{
		var icon = "accept";
	}
	$("#msg_area").html("<div id='msg_area'><div class='message'><div class='"+ type +"'><div class='message_i'><img src='src/img/icons/" + icon + ".png'><a title='close' href='#close' id='close' class='fright'><img src='src/img/icons/cross.png'></a> " + msg + "</div></div></div></div>");
	$(".message").fadeIn("slow");
}
function loadJs(url){
   var e = document.createElement("script");
   e.src = url;
   e.type="text/javascript";
   document.getElementsByTagName("head")[0].appendChild(e);
}
function login(username,password){
	var username = $("#input_username").val();
	var password = $("#input_password").val();
	password = sha1(password);
	var page_content = $("#login_box").html();
	$("#login_box").html("<div id='login_box'> <div style='width:360px;text-align:center;padding:20px 0;'><img src='src/img/site/loading_bar.gif' /></div> </div>");
	$.post("index.php?ajax=login", { username: username, password: password },
	function(data){
		var split=data.split("-"); 
		if(data==""){$("#login_box").html("<div id='login_box'>" + page_content + "</div>");display_message("Login failed to load");}
		else if(data=="error-login"){$("#login_box").html("<div id='login_box'>" + page_content + "</div>");display_message("Invalid login");}
		else if(data=="error-database"){$("#login_box").html("<div id='login_box'>" + page_content + "</div>");display_message("Database offline");}
		else if(split[0]=="success"){
			window.location = split[1];
		}
		else{
			$("#login_box").html("<div id='login_box'>" + page_content + "</div>");display_message("Login failed");
		}
		loadLogin();
	});
}
function loadLogin(){
	$('.button').button();
	$('#input_password').keypress(function(event) {
	if (event.keyCode == '13') {
		event.preventDefault();
		var username = $("#input_username").val();
		var password = $("#input_password").val();
		login(username,password);
	}
	});
	$("#input_username").focus();
}
$(document).ready(function() {
	$("#login_box").dialog({
		title: "Login",
		width: 400,
		draggable: false,
		resizable: false,
		modal: true,
		closeOnEscape: false,
		close: function(){
			window.location.reload();
		},
	
	});
	loadLogin();
	$(".message").fadeIn("slow");
});