function uniqid(){
	var newDate = new Date;
	return newDate.getTime();
}
function site_status(mode){
	$.post("?ajax=site",{mode: mode},
	function(data){
		$("#site_status").html(data);
	});
}
function load_page(page){
	$.get("index.php",{page: page, content:1},
		function(data){
			split=data.split("-");
			if(split[0]=="error"){
				display_msg("error",data);
			}
			else{
				$(".page").hide();
				$("ul li").removeClass("selected");
				$("#link_" + page).addClass("selected");
				var display_prop = $("#page_" + page).css("display");
				if(display_prop=="none"){
					$("#page_"+page).show();
				}
				else{
					if(page=="admin")
						site_status();
					$("#content").prepend("<div class='page' id='page_"+page+"'>"+data+"</div>");
					init_load();
					$("#link_" + page).append(" <a class='close_link' href='javascript:close_page(\""+page+"\");'><img src='src/img/icons/cancel.png'></a> <a class='reload_link' href='javascript:reload_page(\""+page+"\");'><img src='src/img/icons/arrow_refresh.png'></a>");
				}
			}
		});
}
function close_page(page){
	$("ul li").removeClass("selected");
	$("#link_"+page+" .close_link").remove();
	$("#link_"+page+" .reload_link").remove();
	$("#page_"+page).remove();
}
function reload_page(page,data){
	close_page(page);
	load_page(page);
	if(data!=undefined){
		var split = data.split("-");
		display_msg(split[0],split[1]);
	}
}
function display_dialog(title,msg,url,id){
	$("#dialog_area").append("<div id='message_dialog'>" + msg + "</div>");
	$("#message_dialog").dialog({
		title: title,
		draggable: false,
		resizable: false,
		modal: true,
		buttons: {	'Continue': function(){remove(url,id,true);$(this).dialog("close");}
			}
	});
}
function move(from_url,to_url,from_id,to_id,is_dir){
	$.post("?ajax=move",{ from_url: from_url, to_url: to_url, is_dir: is_dir},
	function(data){
		if(data=="success"){
			$("#"+from_id).hide();
			var new_to_id = to_id.substr(5);
			open(to_url,new_to_id,1,true);
		}
		else{
			display_msg("error",data);
		}
	});
}
function remove(url,id,confirm){
	if(confirm==true){
		$.post("?ajax=remove", { url: url },
		  function(data){
			if(data=="success"){
				$("#file_"+id).hide();
			}
			else{
				display_msg("error",data);
			}
		});
	}
	else{
		display_dialog("Confirm Delete","Are you sure you would like to delete this file permanently?",url,id);
	}
}
function rename(url,id,dir_url,dir_id){
	var current_name=$("#file_"+id+" .file_name:first").text();
	var content = "<span id='rename_"+id+"'><input type='text' class='input_rename' value='"+current_name+"'> <a href='#'><img src='src/img/icons/add.png' class='icon'></a></span>";
	$("#file_"+id+" .file_name:first").replaceWith(content);
	$("#rename_"+id+" > .input_rename").focus();
	$("#rename_"+id+" > a").click(function(){
		doRename(url,id,dir_url,dir_id);
	});
	$("#rename_"+id+" > .input_rename").keyup(function(event) {
		if (event.keyCode == '13') {
			event.preventDefault();
			doRename(url,id,dir_url,dir_id);
		}
	});
}
function doRename(url,id,dir_url,dir_id){
	var file_name = $("#rename_"+id+" > input:first").val();
	$.post("?ajax=rename",{file_url:url,file_name:file_name},function(data){
		if(data=="success"){
			display_msg("success","Rename successful");
			$("#rename_"+id).hide();
			open(dir_url,dir_id,true);
		}
		else{
			display_msg("error",data);
		}
	});
}
function create_dir(url,id){
	var create_id=uniqid();
	var content = "<div id='create_dir_"+create_id+"'><input type='text' class='input_create_dir' > <a href='#'><img src='src/img/icons/add.png' class='icon'></a></div>";	
	$("#file_"+id).append(content);
	$("#create_dir_"+create_id+" input").focus();
	$("#create_dir_"+create_id+" > a").click(function(){
		doCreateDir(url,id,create_id);
	});
	$("#create_dir_"+create_id+" > .input_create_dir").keyup(function(event) {
		if (event.keyCode == '13') {
			event.preventDefault();
			doCreateDir(url,id,create_id);
		}
	});
}
function doCreateDir(url,id,create_id){
	var dir_name = $("#create_dir_"+create_id+" > input").val();
	$.post("?ajax=create",{dir_url:url,dir_name:dir_name},function(data){
		if(data=="success"){
			$("#create_dir_"+create_id).hide();
			open(url,id,1,true);
		}
		else if(data=="error-blank"){
			$("#create_dir_"+create_id).hide();
		}
		else if(data=="error-write"){
			$("#create_dir_"+create_id).hide();
			display_msg("error","Unable to write to drive.");
		}
		else{
			$("#create_dir_"+create_id).hide();
			display_msg("error","Unknown error");
		}
	});
}
function open(url,id,refresh){
	var opening_dir=false;
	var display_prop = $("#dir_" + id).css("display");
	if(refresh==true){
		if(display_prop!="none"){
			$("#dir_" + id).remove();
			var value = "refresh";
		}
		else{
			var value = "block";
		}
	}
	else{
		var value = display_prop;
	}
	if(value=="block"){
		$("#dir_" + id).hide();
		$("#file_"+id+" > a > .folder_icon").replaceWith(" <img class='icon folder_icon' src='src/img/icons/folder.png'> ");
		$("#file_"+id+" > a > .drive_icon").replaceWith(" <img class='icon drive_icon' src='src/img/icons/drive_network.png'> ");
	}
	else if(value=="none"){
		$("#dir_" + id).show();
		$("#file_"+id+" > a > .folder_icon").replaceWith(" <img class='icon folder_icon' src='src/img/icons/folder_page.png'> ");
		$("#file_"+id+" > a > .drive_icon").replaceWith(" <img class='icon drive_icon' src='src/img/icons/drive.png'> ");
	}
	else if(opening_dir==false){
		opening_dir=true;
		$("#file_"+id).append("<div class='loading_dir' id='loading_" + id + "'></div>");
		$.get("index.php", {ajax: "drives", url: url},
		function(data){
			$("#loading_"+id).remove();
			$("#file_"+id).append("<div id='dir_" + id + "'>" + data + "</div>");
			$("#file_"+id+" ul li").draggable({ revert: 'invalid' });
			set_droppable(id);
			$("ul li").hover(function(){
				$(this).addClass("hover");
			},function(){
				$(this).removeClass("hover");
			});
			opening_dir=false;
			$("#file_"+id+" > a > .folder_icon").replaceWith(" <img class='icon folder_icon' src='src/img/icons/folder_page.png'> ");
			$("#file_"+id+" > a > .drive_icon").replaceWith(" <img class='icon drive_icon' src='src/img/icons/drive.png'> ");
		});
	}
}
function set_droppable(id){
	if(id==null){
		selector = ".drive_list li";
	}
	else{
		selector = "#file_"+id+" .dir_list  li";
	}
	$(selector).droppable({
		activeClass: 'ui-state-hover',
		hoverClass: 'ui-state-active',
		greedy: true,
		drop: function(event, ui) {
			var to_id = $(this).attr("id");
			var from_id = $(ui.draggable).attr("id");
			var to_url = $(this).children(".location").text();
			var from_url = $(ui.draggable).children(".location").text();
			var list_class =$(ui.draggable).parent("ul").attr("class");
			if(list_class=="dir_list"){
				move(from_url,to_url,from_id,to_id,"true");
			}
			else{
				move(from_url,to_url,from_id,to_id);
			}
		}
		});
}
function show_upload(url,dir_id){
	var upload_id=uniqid();
	var content = '<div id="upload_'+upload_id+'"><iframe src="?page=upload&id='+upload_id+'&trail='+url+'" id="upload_frame" frameborder="0" scrolling"no"></iframe><div id="upload_bar"></div></div>';
	create_pod("Upload to: "+dir_id,content,upload_id);
	$("#upload_"+upload_id+" #upload_bar").progressbar({
		value: 0
	});
	uploadStatus(upload_id,dir_id,url);
}
function uploadStatus(upload_id,file_id,url){
	var t;
	var done = 0;
	$.get("index.php", { ajax: "apc", id: upload_id },
	  function(data){
		//var status = "percent upload: "+data;
		//display_msg("error",data+ " " + upload_id);
		var percent = data * 1;
		if(percent==100){
			display_msg("success","File successfully uploaded");
			clearTimeout(t);
			done = 1;
			close_pod(upload_id);
			open(url,file_id,true);
		}
		else{
			$('#upload_'+upload_id+' #upload_bar').progressbar({value: percent});
		}
		if(done==0){
			t=setTimeout('uploadStatus('+upload_id+',"'+file_id+'","'+url+'")',1500);
		}
	});
	
}
function show_download(url,id){
	var current_text = $("#file_"+id+" .download_box").html();
	if(current_text==null){
		var text_data = $("#file_" + id).html();
		$("#file_" + id).append('<div class="download_box"><iframe class="download_iframe" src="?page=download&url='+url+'" frameborder="0" scrolling="no"></iframe></div>');
	}
}
function display_download(url,title){
	var content = '<div class="download_box"><iframe class="download_iframe" src="?page=download&url='+url+'" frameborder="0" scrolling="no"></iframe></div>';
	create_pod("Download File: "+title,content);
}
function display_image(url,title){
	Shadowbox.open({content: url, title: title, player:"img"});
}
function display_msg(type,message){
	var msg_id=uniqid();
	if(type=="success"){
		var icon_name="accept";
	}
	else{
		var icon_name="cancel";	
	}
	var content = "<div class='message "+type+"' id='msg_"+msg_id+"'><div><img src='src/img/icons/"+icon_name+".png'> "+message+"</div></div>"; 
	$("#msg_area").prepend(content);
	$(".message").addClass("ui-corner-all");
	$("#msg_"+msg_id).fadeIn("slow");
	t=setTimeout('close_msg('+msg_id+')',5000);
}
function close_msg(msg_id){
	$("#msg_"+msg_id).fadeOut("slow");
	$("#msg_"+msg_id).remove();
}
function create_pod(title,content,pod_id,height){
	if(pod_id==null){
		var pod_id=uniqid();
	}
	if(height==null){
		height='\"auto\"';
	}
	var pod_content = "<div id='pod_"+pod_id+"' class='pod_item ui-corner-all'><h3 class='ui-corner-top'><span class='fright'><a href='javascript:hide_pod("+pod_id+","+height+");'></a> <a href='javascript:close_pod("+pod_id+");'><img src='src/img/icons/cross.png'></a></span>"+title+"</h3><div class='pod_content resizable' style='height:"+height+"px'>"+content+"</div></div>";
	$("#pod_area").prepend(pod_content);
	$(".resizable").resizable();
}
function close_pod(pod_id){
	$("#pod_"+pod_id).replaceWith("");
}
function hide_pod(pod_id,height){
	if(height=="auto"){
		var display = $("#pod_"+pod_id+" > .pod_content div").css("display");
		if(display=="none"){
			$("#pod_"+pod_id+" > .pod_content div").show();
			$("#pod_"+pod_id+" .hide_pod_icon").replaceWith("<img class='hide_pod_icon' src='src/img/icons/delete.png'>");
		}
		else{
			$("#pod_"+pod_id+" > .pod_content div").hide();
			$("#pod_"+pod_id+" .hide_pod_icon").replaceWith("<img class='hide_pod_icon' src='src/img/icons/add.png'>");
		}
	}
	else{
		var cheight = $("#pod_"+pod_id+" > .pod_content #fp_"+pod_id).css("height");
		if(cheight=="0px"){
			$("#pod_"+pod_id+" > .pod_content #fp_"+pod_id).css("height",height+"px");
			$("#pod_"+pod_id+" .hide_pod_icon").replaceWith("<img class='hide_pod_icon' src='src/img/icons/delete.png'>");
		}
		else{
			$("#pod_"+pod_id+" > .pod_content #fp_"+pod_id).css("height","0px");
			$("#pod_"+pod_id+" .hide_pod_icon").replaceWith("<img class='hide_pod_icon' src='src/img/icons/add.png'>");
		}
	}
}
function display_media(url,title,type,next,total){
	var style = "style='height:100%';";
	if(type=="audio"){
		var style = "style='height:24px';";
		height = "24";
		var song_name=title;
		title="Music Player";
	}
	else{
		height = "224";
	}
	var media_id=uniqid();
	var content = "<div "+style+" class='media_box' name='"+type+"' id='jw_"+media_id+"'></div>";
	create_pod(title,content,media_id,height);
	$.get("?page=stream",{url: url,type:"link"},
   function(data){
		var split=data.split("~^~");
		if(split[0]=="success"){
			extens = split[1].split(".");
			exten = extens.pop();
			
			$("#jw_"+media_id).css("background","none");
			if(exten=="mp3"){
				$("#pod_"+media_id+" .pod_content").prepend("<ul id='music_playlist'><li>"+song_name+"</li></ul>");
				flowplayer("jw_"+media_id,"src/js/fp/flowplayer-3.2.5.swf",{
				clip: {
					autoPlay: true,
				},
				playlist: [split[1]],
				plugins: {
					controls: {
						backgroundColor: "transparent",
						backgroundGradient: "none",
						sliderColor: '#FFFFFF',
						sliderBorder: '1.5px solid rgba(160,160,160,0.7)',
						volumeSliderColor: '#FFFFFF',
						volumeBorder: '1.5px solid rgba(160,160,160,0.7)',

						timeColor: '#ffffff',
						durationColor: '#535353',

						tooltipColor: 'rgba(255, 255, 255, 0.7)',
						tooltipTextColor: '#000000',
						playlist: true,
						fullscreen: false,
						height: 24,
						autoHide: false
					},
					audio: {
						url: 'src/js/fp/flowplayer.audio-3.2.1.swf'
					}
				}});
				$(".pod_content:first").css("height","auto");
				if(next>0){
					var t = setTimeout("add_music("+next+","+total+")",1000);
				}
			}
			else if(exten=="webm"){
			video_data='<video id="jw_'+media_id+'" autoplay="autoplay" style="width:100%;height:100%" class="video-js" controls="controls" preload="auto"><source src="'+split[1]+'" /></video>';
				$("#jw_"+media_id).append(video_data);
			   var myPlayer = VideoJS.setup("jw_"+media_id);
			}
			else{
				var flashvars = { file:split[1],autostart:'true' };
				var params = { allowfullscreen:'true', allowscriptaccess:'always' };
				var attributes = { id:'player1', name:'player1' };
				swfobject.embedSWF('player.swf',"jw_"+media_id,'100%','100%','9.0.115',false,flashvars, params, attributes);
			}
		}
		else{
			display_msg("error",data);
		}
   });
}
function music_mix(total){
	add_music(0,total);
}
function add_music(current,total){
	current = current * 1;
	if(current>=total){
		return 0;
	}
	var url = $("#song_"+current+" .song_url").text();
	var title = $("#song_"+current+" .song_title").text();
	
	var media_id=$("div[name='audio']:first").attr("id");
	if(media_id==undefined){
		var next = current+1;
		display_media(url,title,"audio", next, total);
		
		//var t = setTimeout("add_music("+next+","+total+")",4000);
	}
	else{
		$.get("?page=stream",{url: url,type:"link"},
		function(data){
			var split=data.split("~^~");
			if(split[0]=="success"){
				$f(media_id).addClip(split[1]);
				var id=media_id.split("_");
				$("#music_playlist").append("<li>"+title+"</li>");
				$(".pod_content:first").css("height","auto");
				display_msg("success",'"'+title+'" added to playlist');
				var next = current + 1;
				add_music(next,total);
			}
			else{
				display_msg("error",data);
			}
		});
	}

}
function run_php(url,page){
	id=uniqid();
	$("body").append("<div id='run_"+id+"'><div style='background:url(src/img/site/loading_bar.gif) center no-repeat;height:50px;'></div></div>");
	$("#run_"+id).dialog({
		title: "Running Script",
		modal: true,
		height: 110,
		width: 200,
		resizable: false
	});
	$.get(url, {mode : "ajax"},
   function(data){
		$("#run_"+id).dialog("destroy");
		var split = data.split("-");
		if(split[0]=="success"){
			display_msg("success",split[1]);
			reload_page(page);
		}
		else{
			display_msg("error",data);
		}
   });
}
function run_ajax(url){
	$.get(url, {mode: "ajax"},
	function(data){
		var split = data.split("-");
		if(split[0]=="success"){
			reload_page(split[1],"success-Settings have been updated");
		}
		else{
			display_msg("error",data);
		}
	});
}
function show_media(medium,type,value,title){
	$.get("index.php",{ ajax: medium, value: value, type: type},
		function(data){
			$("#title_"+medium).replaceWith("<span class='title_media' id='title_"+medium+"> - "+title+"</span>");
			$("#content_"+medium).replaceWith("<div class='content_media' id='content_"+medium+"'>"+data+"</div>");
			init_load();
		});
}
function loadSearch(string){
	var len = string.length;
	if(len<2){
		return;
	}
	else{
		$.get("index.php",{ ajax: "search", term: string},
		function(data){
			if(data==""){
				data = "<p>Sorry, no results found.</p>";
			}
			$("#search_results").html(data);	
		});
	}
}
function init_load(){
	$(".ajaxform").ajaxForm(function(data){
		var split = data.split("-");
		if(split[0]=="success"){
			reload_page(split[1],"success-Settings have been updated");
		}
		else if(split[0]=="refresh"){
			window.location.reload();
		}
		else{
			display_msg("error",data);
		}
	});
	$(".resizable").resizable();
	$("#link_recyclebin").click();
	$("#top_nav ul li").hover(function(){
		$(this).addClass("hover");
	},function(){
		$(this).removeClass("hover");
	});
	$("input:file").button({icons: {primary: 'ui-icon-disk'}});
	$("#input_search").keyup(function(){
		var string = $("#input_search").val();
		loadSearch(string);
	});
	$("#input_search").focus();
	$("h2, ul li, .success, .error, .box, .warning, input").addClass("ui-corner-all");
	$(".message").fadeIn("slow");
	$("#close").click(function() {
		$(this).parents(".message").fadeOut("slow");
	});
	$(".button").hover(
		function(){ 
			$(this).addClass("ui-state-hover"); 
		},
		function(){ 
			$(this).removeClass("ui-state-hover"); 
	});
	set_droppable();
	$(".button,input:submit").button();
	$(".button-play").button({icons: { primary: "ui-icon-play" }});
	$(".button-update").button({icons: { primary: "ui-icon-refresh" }});
	$(".progress").progressbar();
}
$(document).ready(function() {
	init_load();
});
Shadowbox.init({
    skipSetup: true
});