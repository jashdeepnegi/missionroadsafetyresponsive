function downloadStatus(file_id){
	var t;
	$.get("?ajax=status&id=" + file_id, { type: "Ajax" },
	  function(data){
		var data = data * 1;
		if(data==100){
			location.reload(true);
			clearTimeout(t); 
		}
		$('#progressbar').progressbar({value: data});
	});
	t=setTimeout("downloadStatus('" + file_id + "')",1000);
}
$(document).ready(function() {
	$(".button").button();
	$("#download_button").button({icons: {primary: 'ui-icon-disk'}});
	$(".button").hover(
			function(){ 
				$(this).addClass("ui-state-hover"); 
			},
			function(){ 
				$(this).removeClass("ui-state-hover"); 
		});
	$("input").focusin(
		function(){
			$(this).addClass('active');
		}
	);
	$("input").focusout(
		function(){
			$(this).removeClass('active');
		}
	);
});	