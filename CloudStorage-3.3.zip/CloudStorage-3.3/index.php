<?php
//Cloud Storage 3.3 3/30/2011
session_start();

if(!file_exists('inc/config.php')){
	header("Location: install/index.php");
	exit();
}	

require_once('inc/config.php');
require_once('inc/connect.php');
require_once('inc/lib/core.php');
require_once('inc/lib/image.php');
require_once('inc/lib/getid3/getid3.php');

$load_page="index";
$load_ajax=null;
if(isset($_GET['page'])){
	$load_page=$_GET['page'];
	if($load_page=="login"&&$login!="")
		redirect("index.php");
}
if(isset($_GET['ajax'])){
	$load_ajax=$_GET['ajax'];	
}
if($login==null&&$load_page!="login"&&$load_ajax!="login"&&$load_page!="alogin"&&$load_ajax!="alogin"){
	$_SESSION['ref']=$url;
	redirect("?page=login");
}
if(!isset($_GET['msg']))
	$_GET['msg']=null;
if(isset($_GET['logout'])){
	session_destroy();
	if(isset($me))
		redirect($logoutUrl);
	redirect("?page=login&msg=login_out");
}
elseif(isset($require_admin)&&$require_admin==true){
	if($login!="admin"){
		redirect("error.php?id=4");
	}
}
elseif($login=="admin"&&$load_ajax!="admin"&&$_GET['msg']!="require_recyclebin"&&$_GET['msg']!="require_tmpdrive"){
	$result=mysql_query("SELECT * FROM file_drives WHERE name='recyclebin' LIMIT 1");
	if(mysql_num_rows($result)<1){
		redirect("?page=admin&msg=require_recyclebin");
	}
	$result=mysql_query("SELECT * FROM file_drives WHERE name='tmp' LIMIT 1");
	if(mysql_num_rows($result)<1){
		redirect("?page=admin&msg=require_tmpdrive");
	}
}
elseif($login=="admin"&&$load_page=="admin"&&($_GET['msg']=="require_recyclebin"||$_GET['msg']=="require_tmpdrive")){
	if($_GET['msg']=="require_recyclebin"){
		$result=mysql_query("SELECT * FROM file_drives WHERE name='recyclebin' LIMIT 1");
		if(mysql_num_rows($result)>0){
			redirect("?page=admin");
		}
	}
	else{
		$result=mysql_query("SELECT * FROM file_drives WHERE name='tmp' LIMIT 1");
		if(mysql_num_rows($result)>0){
			redirect("?page=admin");
		}
	}
}

if(!file_exists("tmp/"))
	mkdir("tmp/");
if(!file_exists("tmp/file/"))
	mkdir("tmp/file");
if(!file_exists("tmp/img/"))
	mkdir("tmp/img");

if($load_ajax!=null){
	if(!validate_username($load_ajax)){
		echo "error-invalid_ajax";exit;
	}
	if(file_exists('inc/ajax/'.$load_ajax.'.php')){
		require_once('inc/ajax/'.$load_ajax.'.php');
	}
	elseif(file_exists('inc/plugins/'.$load_ajax.'/content.php')){
		
		if(isset($_GET['exten'])){
			if($_GET['exten']=="css")
				header("Content-type: text/css");
			elseif($_GET['exten']=="js")
				header("Content-type: text/javascript");
			else
				exit;
			echo file_get_contents('inc/plugins/'.$load_ajax.'/default.'.$_GET['exten']);
		}	
		else
			require_once('inc/plugins/'.$load_ajax.'/content.php');
		
	}
	else{
		echo "error-no_ajax_file";exit;
	}
}
else{
	load_page($load_page);	
}