<?php
$correct=false;
$username=strtolower(trim($_POST['username']));
$password=$_POST['password'];
if($username!=""&&$password!=""){
	if($username=="admin"){
		if($password==sha1($config_admin_password)){
			$correct=true;
			$login_id=0;
		}
	}
	elseif($db_fail){
		sleep(2);
		echo "error-database";
		exit;
	}
	else{
		$result=mysql_query("SELECT * FROM users WHERE username='$username' AND password='$password' LIMIT 1");
		if(mysql_num_rows($result)>0){
			while($row=mysql_fetch_array($result)){
				$correct=true;
				$login_id=$row['id'];
			}
		}
	}
}
if($correct==true){
	$_SESSION['login']=$username;
	$_SESSION['login_id']=$login_id;
	$location="index.php";
	sleep(1);
	echo "success-$location";
}
else{
	sleep(2);
	echo "error-login";
}