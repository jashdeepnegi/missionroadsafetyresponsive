<?php
$url = base64_decode($_GET['url']);

$drive=reset(explode("/",$url));
$submap_dir=submap_dir($drive);
if(!$submap_dir)
	redirect("no drive $drive");
$trail=substr($url,strlen($drive)+1);
$current_path="$submap_dir/$trail";
$can_upload=false;
$can_edit=false;

if(!is_dir($current_path))
	redirect("no path $current_path");
if(!permission($drive,"view"))
	redirect("no-permission");
if(permission($drive,"upload"))
	$can_upload=true;
if(permission($drive,"edit"))
	$can_edit=true;

$url_link="$drive/$trail";
$this_id=create_id(substr($url_link,0,-1));

$dir=$current_path;
$dh = opendir($dir);
$files=array();
$dirs=array();
while (($file = readdir($dh)) !== false) {
	if(!in_array($file,$hidden_files)){
		if(is_dir("$dir/$file"))
			$dirs[]=$file;
		else
			$files[]=$file;
	}
}
$recycle_bin = base64_encode("recyclebin/");
closedir($dh);
if(count($dirs)>0){
	asort($dirs);
	echo "<ul class='dir_list'>";
	foreach($dirs as $dir){
		$dir_url = $url_link.$dir."/";
		$dir_id=create_id($dir_url);
		$up_url = base64_encode($url_link);
		$dir_url=base64_encode($dir_url);
		
		echo "<li class='ui-corner-all' id='file_$dir_id'><span class='location'>$dir_url</span>";
		echo "<span class='fright'>";
		if($can_upload)
			echo "<a title='Upload File' href='javascript:show_upload(\"$dir_url\",\"$dir_id\");'><img src='src/img/icons/page_add.png'></a> ";
		if($can_edit){
			echo "<a title='Create new Folder' href='javascript:create_dir(\"$dir_url\",\"$dir_id\");'><img src='src/img/icons/folder_add.png'></a> ";
			echo "<a title='Rename Folder' href='javascript:rename(\"$dir_url\",\"$dir_id\",\"$up_url\",\"$this_id\");'><img src='src/img/icons/folder_edit.png'></a> ";
		}
		if($drive=="recyclebin")
			echo "<a title='Delete File' href='javascript:remove(\"$dir_url\",\"$dir_id\");'><img src='src/img/icons/delete.png'></a>";
		elseif($can_edit)
			echo "<a title='Delete File' href='javascript:move(\"$dir_url\",\"$recycle_bin\",\"file_$dir_id\",\"file_recyclebin\",\"true\");'><img src='src/img/icons/delete.png'></a>";
		echo "</span><a href='javascript:open(\"$dir_url\",\"$dir_id\");'><img class='icon folder_icon' src='src/img/icons/folder.png'> <span class='file_name'>$dir</span></a></li> \n";
	}
	echo "</ul>";
}
if(count($files)>0){
	asort($files);
	echo "<ul class='file_list'>";
	foreach($files as $file){
		$file_url = $url_link.$file;
		$file_id=create_id($file_url.rand(1000,9999));
		$file_url = base64_encode($file_url);
		$dir_url = base64_encode($url_link);

		
		$file_name = create_name($file);
		$file_path=$current_path.$file;
		$filesize=filesize2($file_path);
		$ext=file_extension($file_path);
		$image_class=null;
		if(in_array($ext,$image_extens))
			$image_class = 'thumb_file_list';
		echo "<li class='ui-corner-all $image_class' id='file_$file_id'><span class='location'>$file_url</span><span class='fright'>$filesize ";
		if($can_edit)
			echo "<a title='Rename File' href='javascript:rename(\"$file_url\",\"$file_id\",\"$dir_url\",\"$this_id\");'><img src='src/img/icons/page_edit.png'></a>";
		if($drive=="recyclebin")
			echo "<a title='Delete File' href='javascript:remove(\"$file_url\",\"$file_id\");'><img src='src/img/icons/delete.png'></a>";
		elseif($can_edit)
			echo "<a title='Delete File' href='javascript:move(\"$file_url\",\"$recycle_bin\",\"file_$file_id\",\"file_recyclebin\");'><img src='src/img/icons/delete.png'></a>";
		echo "</span>";
		if(in_array($ext,$image_extens))
			echo " <a title='View Image' href='javascript:display_image(\"?page=image&url=$file_url\",\"$file_name\");'><img class='img_thumbnail' alt=\"$file_id\" src=\"?page=thumb&url=$file_url\"></a> ";
		if(in_array($ext,$video_extens))
			echo " <a title='Play Video' href='javascript:display_media(\"$file_url\",\"$file_name\");'><img src='src/img/icons/film.png'></a> ";
		if(in_array($ext,$audio_extens))
			echo " <a title='Play Audio' href='javascript:display_media(\"$file_url\",\"$file_name\",\"audio\");'><img src='src/img/icons/sound.png'></a> ";
		echo "<a title='Download File' href='javascript:display_download(\"$file_url\",\"$file_name\");'><img src='src/img/icons/drive_disk.png'></a> ";
		echo "<span class='file_name'><a title='Download File' href='javascript:display_download(\"$file_url\",\"$file_name\");'>$file</a></span></li> \n";
	}
	echo "</ul>";
}