<?php
if(!isset($_GET['term']))
	exit;
$search_query=trim(mysql_escape_string($_GET['term']));
if (empty($search_query))
	exit;
$perms=array();
$editable = array();
$result = mysql_query("SELECT * FROM file_drives WHERE name!='tmp' AND name!='recyclebin'");
while($row = mysql_fetch_array($result)){
	if(permission($row['name'],"view")){
		$perms[]=$row['id'];
		$drives[$row['id']]=$row;
		if(permission($row['name'],"edit"))
			$editable[]=$row['id'];
	}
}
if(count($perms)==0)
	exit;
$perms=implode("','",$perms);
$result=mysql_query("SELECT * FROM file_map WHERE title LIKE '%$search_query%' AND title!='' AND exten!='' AND drive IN ('$perms') ORDER BY title ASC");
$count = mysql_num_rows($result);
$result=mysql_query("SELECT * FROM file_map WHERE title LIKE '%$search_query%' AND title!='' AND exten!='' AND drive IN ('$perms') ORDER BY title ASC LIMIT 40");
if($count==0){
	exit;
}

echo "<h3>$count Results</h3>";
echo "<ul class='file_list'>";
$this_id=create_id($search_query);
while($row=mysql_fetch_array($result)){
	$file_path=$drives[$row['drive']]['submap_dir']."/".$row['path'];
	if(!file_exists($file_path))
		continue;
	$file_url = $drives[$row['drive']]['name']."/".$row['path'];
	$file_id=create_id($file_url.rand(1000,9999));
	$file_url=base64_encode($file_url);
	
	$file_name = create_name($row['title']);
	$can_edit = false;
	if(in_array($row['drive'],$editable))
		$can_edit = true;
	$filesize=filesize2($file_path);
	$ext=$row['exten'];
	$image_class=null;
	
	if(in_array($ext,$image_extens))
		$image_class = 'thumb_file_list';
	echo "<li class='ui-corner-all $image_class' id='file_$file_id'><span class='location'>$file_url</span><span class='fright'>$filesize </span>";
	if(in_array($ext,$image_extens))
		echo " <a title='View Image' href='javascript:display_image(\"?page=image&url=$file_url\",\"$file_name\");'><img class='img_thumbnail' alt=\"$file_id\" alt=\"No Image\" src=\"?page=thumb&url=$file_url\"></a> ";
	if(in_array($ext,$video_extens))
		echo " <a title='Play Video' href='javascript:display_media(\"$file_url\",\"$file_name\");'><img src='src/img/icons/film.png'></a> ";
	if(in_array($ext,$audio_extens))
		echo " <a title='Play Audio' href='javascript:display_media(\"$file_url\",\"$file_name\",\"audio\");'><img src='src/img/icons/sound.png'></a> ";
	echo "<a title='Download File' href='javascript:display_download(\"$file_url\",\"$file_name\");'><img src='src/img/icons/drive_disk.png'></a> ";
	echo "<span class='file_name'><a title='Download File' href='javascript:display_download(\"$file_url\",\"$file_name\");'>$row[title]</a></span></li> \n";
}
echo "</ul>";