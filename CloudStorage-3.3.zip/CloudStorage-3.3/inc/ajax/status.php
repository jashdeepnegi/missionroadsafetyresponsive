<?php
if(!isset($_GET['id']))
	redirect("error-no id");
$id=$_GET['id'];	
if(!is_numeric($id))
	redirect("error-invalid id");
$result=mysql_query("SELECT * FROM temp_files WHERE id='$id' LIMIT 1");
if(mysql_num_rows($result)==0)
	redirect("error-no temp file");
while($row=mysql_fetch_array($result)){
	$temp_size=0;
	$file_name=end(explode("/",$row['file']));
	$temp_path="tmp/file/$row[id]-$row[rand]/$file_name";
	if(file_exists($temp_path))
		$temp_size=filesize($temp_path);
	else
		redirect("no file $temp_path");
	$percent=$temp_size/$row['size'];
	$percent=100*$percent;
	$percent=floor($percent);
	echo $percent;
}