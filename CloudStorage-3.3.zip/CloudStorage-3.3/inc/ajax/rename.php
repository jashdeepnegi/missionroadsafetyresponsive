<?php
$file_name=$_POST['file_name'];
$file_url=base64_decode($_POST['file_url']);

$file_drive=reset(explode("/",$file_url));
if(!empty($file_drive)){
	if(!permission($file_drive,"edit")){
		echo "error-permission";
	}
	else{
		$submap_file_drive=submap_dir($file_drive);
		$trail_file_drive=end(explode("$file_drive/",$file_url));
		$file_path="$submap_file_drive/$trail_file_drive";
		
		$dir_path = dirname($file_path);
		$new_path="$dir_path/$file_name";
		if(is_dir($file_path)){
			$new_path="$new_path/";
		}
		if($new_path!=$file_path){
			$i=1;
			while(file_exists($new_path)){
				if(!is_dir($file_path)){
					$exten=file_extension($new_path);
					$before_exten=reset(explode(".$exten",$new_path));
					$new_path="$before_exten ($i).$exten";
				}
				else{
					$new_path="$new_path ($i)";
				}	
				$i++;
			}
			rename($file_path,$new_path);
		}
		echo "success";
	}
}
else{
	echo "error-drive $file_url";
}