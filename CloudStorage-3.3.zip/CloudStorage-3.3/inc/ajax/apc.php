<?php
$key="upload_$_GET[id]";
$tmp_file="tmp/$_GET[id].done";
if(function_exists("apc_fetch")){
	$status=apc_fetch($key);
	if(file_exists($tmp_file)){
		unlink($tmp_file);
		echo "100";
	}
	elseif($status&&$status['total']>0){
		$percent=$status['current']/$status['total'];
		$percent=ceil($percent*100);
		echo $percent;
	}
	else
		echo "0";
}
else{
	if(file_exists($tmp_file)){
		unlink($tmp_file);
		echo "100";
	}
	else
		echo "0";
}