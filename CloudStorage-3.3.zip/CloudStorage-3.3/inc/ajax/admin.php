<?php
$users=array();
$drives=array();
$result=mysql_query("SELECT * FROM users WHERE username!='admin' ORDER BY username");
while($row=mysql_fetch_array($result)){
	$users[]=$row;
}
$result=mysql_query("SELECT * FROM file_drives ORDER BY name");
while($row=mysql_fetch_array($result)){
	$drives[]=$row;
}
$actions=array("view","upload","edit");
if(isset($_GET['del_user'])){
	$sql_del_user=mysql_escape_string($_GET['del_user']);
	mysql_query("DELETE FROM users WHERE username='$sql_del_user'");
	redirect("success-admin");
}
elseif(isset($_GET['del_drive'])){
	$sql_del_drive=mysql_escape_string($_GET['del_drive']);
	mysql_query("DELETE FROM file_drives WHERE name='$sql_del_drive'");
	redirect("success-admin");
}
elseif(isset($_POST['send'])){
	if(isset($_POST['new_user'])&&trim($_POST['new_user'])!=""){
		$sql_new_user=mysql_escape_string(strtolower(trim($_POST['new_user'])));
		$sql_new_pass=sha1($_POST['new_pass']);
		mysql_query("INSERT INTO users (username,password) VALUES ('$sql_new_user','$sql_new_pass')");
	}
	if(isset($_POST['new_drive'])&&trim($_POST['new_drive'])!=""&&trim($_POST['new_drive_path'])!=""){
		$add_drive=true;
		if(file_exists($_POST['new_drive_path'])){
			if(!is_dir($_POST['new_drive_path'])){
				$add_drive=false;
			}
		}
		else{
			mkdir($_POST['new_drive_path']);
		}
		if($add_drive==true){
			$sql_new_drive=strtolower(mysql_escape_string($_POST['new_drive']));
			$sql_new_drive_path=mysql_escape_string($_POST['new_drive_path']);
			mysql_query("INSERT INTO file_drives (name,submap_dir) VALUES ('$sql_new_drive','$sql_new_drive_path')");
		}
	}
	foreach($users as $user){
		$post_password="password_".$user['username'];
		if(!empty($_POST[$post_password])){
			$sql_user_password=sha1($_POST[$post_password]);
			mysql_query("UPDATE users SET password='$sql_user_password' WHERE username='$user[username]' LIMIT 1");
		}
	}
	foreach($drives as $drive){
		$drive_name=$drive['name'];
		if(!empty($_POST[$drive_name])){
			$sql_drive_path=mysql_escape_string($_POST[$drive_name]);
			$sql="UPDATE file_drives SET submap_dir='$sql_drive_path' WHERE name='$drive[name]' LIMIT 1";
			mysql_query($sql);
		}
		foreach($actions as $action){
			$ausers=array();
			foreach($users as $user){
				$post_drive="$drive[name]_$action"."_"."$user[id]";
				if(isset($_POST[$post_drive])&&$_POST[$post_drive]=="1"){
					$ausers[]=$user['id'];
				}
			}
			$allowed=implode(",",$ausers);
			mysql_query("UPDATE file_drives SET $action='$allowed' WHERE name='$drive[name]'");
		}
	}
	if(isset($_POST['refresh']))
		redirect("refresh-admin");
	else
		redirect("success-admin");
}