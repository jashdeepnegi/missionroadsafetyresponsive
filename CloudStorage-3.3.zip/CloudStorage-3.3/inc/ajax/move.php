<?php
if(isset($_POST['is_dir'])&&$_POST['is_dir']=="true"){
	$from_url=substr(base64_decode($_POST['from_url']),0,-1);
}
else{
	$from_url=base64_decode($_POST['from_url']);
}
$to_url=substr(base64_decode($_POST['to_url']),0,-1);

$from_drive=reset(explode("/",$from_url));
$to_drive=reset(explode("/",$to_url));

if(empty($from_drive)||empty($to_drive)){
	echo "error-drive $from_drive > $to_drive";
}
else{
	if(!permission($from_drive,"edit")){
		echo "error-permission";
	}
	elseif(!permission($to_drive,"edit")&&$to_drive!="recyclebin"){
		echo "error-permission";
	}
	else{
		$submap_from_drive=submap_dir($from_drive);
		$submap_to_drive=submap_dir($to_drive);
		
		$trail_from_drive=end(explode($from_drive,$from_url));
		$trail_to_drive=end(explode($to_drive,$to_url));

		$from_name=end(explode("/",$from_url));
		$from_path=$submap_from_drive.$trail_from_drive;
		$to_path=$submap_to_drive.$trail_to_drive."/".$from_name;
		
		$i=1;
		if(!file_exists($from_path)){
			echo "error-filemissing ($from_path)";
		}
		else{
			if($to_path!=$from_path){
				while(file_exists($to_path)){
					if(isset($_POST['is_dir'])&&$_POST['is_dir']!="true"){
						$exten=file_extension($to_path);
						$before_exten=reset(explode(".$exten",$to_path));
						$to_path="$before_exten ($i).$exten";
					}
					else{
						$to_path="$to_path ($i)";
					}	
					$i++;
				}
				rename($from_path,$to_path);
			}
			echo "success";
		}
	}
}