<?php
$dir_name=trim($_POST['dir_name']);
$dir_url=base64_decode($_POST['dir_url']);
$dir_drive=reset(explode("/",$dir_url));
if(!permission($dir_drive,"edit")){
		echo "error-permission";
}
else{
	if(empty($dir_name)){
		echo "error-blank";
	}
	else{
		$submap_dir_drive=submap_dir($dir_drive);
		$trail_dir_drive=end(explode($dir_drive,$dir_url));
		$file_path=$submap_dir_drive.$trail_dir_drive.$dir_name;
		$i=1;
		while(file_exists($file_path)){
			$file_path="$file_path ($i)";
			$i++;
		}
		if(mkdir($file_path)){
			echo "success";
		}
		else{
			echo "error-write";	
		}
	}
}