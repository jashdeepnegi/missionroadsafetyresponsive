<?php
$url=base64_decode($_POST['url']);
$drive=reset(explode("/",$url));
if(empty($drive)){
	echo "error-drive";
}
else{
	if(!permission($drive,"edit")){
		echo "error-permission";
	}
	else{
		$submap_dir=submap_dir($drive);
		$trail=end(explode($drive,$url));
		$path="$submap_dir".$trail;
		if(!file_exists($path)){
			echo "error-exists";
		}
		else{
			if(is_dir($path)){
				delTree($path);
			}
			else{
				unlink($path);
			}
			echo "success";
		}
	}
}