<?php
if(!isset($_GET['type']))
	redirect("error-No type");
$value = mysql_escape_string($_GET['value']);
switch($_GET['type']){
	case 'artist':
		$result=mysql_query("SELECT * FROM music_map WHERE artist_id='$value'");
		break;
	case 'year':
		$result=mysql_query("SELECT * FROM music_map WHERE year='$value'");
		break;
	case 'genre':
		$result=mysql_query("SELECT * FROM music_map WHERE genre='$value'");
		break;
	default:
		redirect("error");
}
$count=mysql_num_rows($result);
if($count==0){
	echo "<p>No songs found</p>";	
}
else{
	$ten = min(10,$count);
	echo "<a href='javascript:music_mix($count);' class='button-play'>Add All ($count)</a> ";
	echo "<a href='javascript:music_mix($ten);' class='button-play'>Add First 10</a> ";
	echo "<ul id='music_list'>";
	$i = 0;
	while($row=mysql_fetch_array($result)){
		$result2=mysql_query("SELECT * FROM file_map WHERE id='$row[file_id]' LIMIT 1");
		while($row2=mysql_fetch_array($result2)){
			$drive_name = get_drive($row2['drive']);
			if(!permission($drive_name,"view"))
				continue;
			$url=base64_encode($drive_name."/".$row2['path']);
		}
		$artist=null;
		if($_GET['type']!='artist'){
			$result3=mysql_query("SELECT * FROM music_artists WHERE id='$row[artist_id]' LIMIT 1");
			while($row3=mysql_fetch_array($result3)){
				$artist="$row3[name] -";
			}
		}
		
		$length = format_time($row['playtime']);
		$rate = round($row['bitrate']/1000);
		echo "<li id='song_$i'><span class='fright'>$length @ $rate"."kbps</span>";
		echo "<span class='song_url hidden'>$url</span>";
		echo "<a title='download' href='javascript:display_download(\"$url\",\"$artist $row[song]\",\"audio\");'><img src='src/img/icons/drive_disk.png'></a> ";
		echo "<a title='add to playlist' href='javascript:add_music(\"$i\",\"".($i+1)."\",\"audio\");'><img src='src/img/icons/sound_add.png'></a> ";
		echo "<a title='play now' href='javascript:display_media(\"$url\",\"$artist $row[song]\",\"audio\");'><img src='src/img/icons/sound.png'> <span class='song_title'>$artist $row[song]</span></a></li>";
		$i++;
	}
	echo "</ul>";
}
