<?php
if(!isset($_GET['option']))
	redirect("error-no option");
require_once(dirname(__FILE__)."/../lib/cron.php");
if($_GET['option']=="index")
	echo cronIndex();
elseif($_GET['option']=="music")
	echo cronMusic();