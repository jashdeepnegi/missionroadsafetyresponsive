<?php
$return = shell_exec('man ffmpeg');
sleep(0.2);
$warning_msg=array();
if($return==""){
	$warning_msg[]="You do not have ffmpeg installed, videos will not be thumbnailed (<a target='_blank' href='http://www.ffmpeg.org/download.html'>Help</a>)</div>";
}
if(!function_exists("imagecreatetruecolor")){
	$warning_msg[]="The GD php library needs to be installed (<a target='_blank' href='http://www.php.net/manual/en/image.installation.php'>Help</a>)";
}
if(!function_exists("apc_fetch")){
	$warning_msg[]="The APC php library needs to be installed (<a target='_blank' href='http://www.php.net/manual/en/apc.installation.php'>Help</a>)";
}
if(!function_exists("popen")){
	$warning_msg[]="The Popen function needs to be enabled";	
}
foreach($warning_msg as $msg){
	echo "<div class='warning'><img class='icon' src='src/img/icons/error.png'> <b>Warning:</b> $msg</div>";
}
if(count($warning_msg)==0){
	echo "<p>The site is running properly.</p>";
}