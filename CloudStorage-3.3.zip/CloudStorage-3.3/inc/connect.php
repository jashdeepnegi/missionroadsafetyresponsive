<?php
$db_fail=false;
$con = mysql_connect($config_db_host,$config_db_username,$config_db_password);
if (!$con){
	$db_fail=true;
	redirect("error.php?id=3");
}
if($db_fail==false){
	mysql_select_db($config_db_name, $con);
}