<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
	<head>
		<title>Cloud Storage</title>
		<link type="text/css" href="<?php echo $site_url;?>src/js/jq/ui/theme/ui-lightness/default.css" rel="stylesheet" />	
		<script type="text/javascript" src="<?php echo $site_url;?>src/js/jq/jquery.js"></script>
		<script type="text/javascript" src="<?php echo $site_url;?>src/js/jq/ui/ui.js"></script>
		<link rel="stylesheet" type="text/css" href="<?php echo $site_url;?>src/css/lite.css">
		<script type="text/javascript" src="<?php echo $site_url;?>src/js/lite.js"></script> 
	</head>
	<body>
		<div id="page">
			<div id="complete">
				<div id="main">
					<div id="main_inside">
						<?php display_content();?>
					</div>
				</div>
			</div>
		</div>
	</body>
</html>