<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
	<head>
		<title>Cloud Storage</title>
		<link type="text/css" href="<?php echo $site_url;?>src/js/jq/ui/theme/ui-lightness/default.css" rel="stylesheet" />
		<link rel="stylesheet" type="text/css" href="<?php echo $site_url;?>src/js/sb/shadowbox.css">
		<link rel="stylesheet" type="text/css" href="<?php echo $site_url;?>src/js/video/video-js.css">
		<link rel="stylesheet" type="text/css" href="<?php echo $site_url;?>src/css/default.css">
		<script type="text/javascript" src="<?php echo $site_url;?>src/js/jw/swfobject.js"></script>
		<script type="text/javascript" src="<?php echo $site_url;?>src/js/fp/flowplayer-3.2.4.min.js"></script>
		<script type="text/javascript" src="<?php echo $site_url;?>src/js/jq/jquery.js"></script>
		<script type="text/javascript" src="<?php echo $site_url;?>src/js/jq/ui/ui.js"></script>
		<script type="text/javascript" src="<?php echo $site_url;?>src/js/video/video.js"></script>
		<script type="text/javascript" src="<?php echo $site_url;?>src/js/sb/shadowbox.js"></script>
		<script type='text/javascript' src='<?php echo $site_url;?>src/js/jq/form.js'></script>
		<script type="text/javascript" src="<?php echo $site_url;?>src/js/default.js"></script>
		<?php
		if($_GET['msg']=="require_recyclebin"||$_GET['msg']=="require_tmpdrive")
			echo "<style type='text/css'>#header,#left_pane{display:none;}#content{padding-left:5px;}</style>";
		?>
	</head>
	<body>
		<div id="fb-root"></div>
		<div id="page">
		<div id="complete">
			<div id="header">
				<div id="top_nav">
				<ul class="fright">
				<li><a href="?logout=1"><img src="<?php echo $site_url;?>src/img/icons/user.png"><b><?php echo ucwords(login); ?> </b>Logout</a></li>
				</ul>
				<ul>
				<li id='link_home'><a href="javascript:load_page('home');"><span><img src='<?php echo $site_url;?>src/img/icons/drive_network.png'> File Drives</a></span></li>
				<li id='link_search'><a href="javascript:load_page('search');"><img src='<?php echo $site_url;?>src/img/icons/zoom.png'> Search</a></li>
				<li id='link_music'><a href="javascript:load_page('music');"><img src='<?php echo $site_url;?>src/img/icons/music.png'> Music</a></li>
				<?php
				if(login=="admin")
					echo "<li id='link_admin'><a href='javascript:load_page(\"admin\");'><img src='$site_url"."src/img/icons/wand.png'> Admin</a></li>";
				?>
				</ul>
				</div>
				<div class='clearboth'></div>
			</div>
			<?php display_msg(); ?>
			<div id="main">
					<div id="main_inside">
					<table id="pane_table">
				<tr><td id='left_pane'>
					<div class="pane-inner">
						<h2>Pods</h2>
						<div id="pod_area">
						</div>
					</div>
				</td>
				<td id="right_pane">
					<div id="content">
						<div id="page_index" class='page'>
							<?php display_content();?>
						</div>
					</div>
				</td></tr>
			</table>
		<div id="msg_area"></div>
		<div id="dialog_area"></div>
		</div>
		</div>
		</div>
		<script type="text/javascript">
		  var _gaq = _gaq || [];
		  _gaq.push(['_setAccount', 'UA-20564673-1']);
		  _gaq.push(['_setDomainName', '.clouthe.com']);
		  _gaq.push(['_trackPageview']);

		  (function() {
			var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
			ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
			var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
		  })();

		</script>
	</body>
</html>