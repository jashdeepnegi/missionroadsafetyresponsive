<?php
define("APPLICATION_ENV","DEVELOPMENT");
define("OFFICIAL_URL","http://cloudstorage.sourceforge.net/");
define("VERSION_NUMBER","3.2");
$version_number=constant('VERSION_NUMBER');
$ip=$_SERVER['REMOTE_ADDR'];

$login_id=null;	
$login=null;

$image_extens=array("jpg","jpeg","png","gif");
$video_extens=array("flv","f4v","mp4","webm","m4v","ogg");
$audio_extens=array("mp3");
$hidden_files=array(".","..",".htaccess","desktop.ini","Thumbs.db","System Volume Information","ZbThumbnail.info",".htpasswd",".DS_Store");

if(isset($_SESSION['login'])){
	$login=$_SESSION['login'];
	$login_id=$_SESSION['login_id'];
	define("login",$login);
	define("login_id",$login_id);
}

$user_agent=$_SERVER['HTTP_USER_AGENT'];
$url=str_replace("+","%2B",$_SERVER['REQUEST_URI']);
$url=urldecode($url);
$script=end(explode("/",$_SERVER["SCRIPT_NAME"]));

$splits=array_reverse(explode("/",reset(explode("?",$_SERVER['REQUEST_URI']))));
if(isset($splits[2])&&$splits[2]=="src")
	$site_url="../../";
else
	$site_url=null;

$full_url = "http://$_SERVER[HTTP_HOST]/$site_url";

define("FULL_URL",$full_url);
define("SITE_URL",$site_url);

function system_log($message,$type="error"){
	$login=null;
	if(defined("login"))
		$login = login;
	return mysql_query("INSERT INTO logs (type,message,ip,uri,user_agent,user_id) VALUES('$type','$message','$_SERVER[REMOTE_ADDR]','$_SERVER[REQUEST_URI]','$_SERVER[HTTP_USER_AGENT]','$login')");
}
function generate_thumbnail($from,$to,$time){
	$cmd = "ffmpeg -i \"$from\" -deinterlace -an -ss $time -t 00:00:01 -r 1 -y -vcodec mjpeg -f mjpeg \"$to\" 2>&1";
	$return = shell_exec($cmd);
	return true;
}
function list_permissions($drive,$allowed,$users,$action){
	foreach($users as $user){
		$checked=null;
		if($allowed!=""){
			$ausers=explode(",",$allowed);
			if(in_array($user['id'],$ausers))
				$checked=" checked='checked' ";
		}
		echo "<input type='checkbox' name='$drive"."_"."$action"."_"."$user[id]' $checked value='1'> $user[username] <br />";
	}
}
function load_page($name){
	define("load_page",$name);
	function display_content(){
		$rel_up=null;
		if(file_exists("inc/page/".load_page."/content.php"))
			include("inc/page/".load_page."/content.php");
		elseif(file_exists("inc/plugins/".load_page."/content.php"))
			include("inc/plugins/".load_page."/content.php");
	}
	$site_url=SITE_URL;
	if(isset($_GET['content']))
		display_content();	
	elseif(file_exists("inc/page/".load_page."/head.php"))
		include("inc/page/".load_page."/head.php");
	else
		if(file_exists("inc/templates/default/$name.php"))
			include("inc/templates/default/$name.php");
		else
			include("inc/templates/default/index.php");
}
function import_mysql($file){
	if(!file_exists($file))
		return false;
	$sql_query=explode(";",str_replace("\n","",file_get_contents($file)));
	foreach($sql_query as $query){
		if(trim($query)!=""){
			if(!mysql_query($query)){
				echo "ERROR: $query<hr>";
				return false;
			}
		}
	}
	return true;
}
function permission($drive,$action){
	if(login=="admin")
		return true;
	if($drive=="demo"&&$action=="view")
		return true;
	$sql_drive=mysql_escape_string($drive);
	$result=mysql_query("SELECT * FROM file_drives WHERE name='$sql_drive' LIMIT 1");
	while($row=mysql_fetch_array($result)){
		if($row[$action]!=""){
			$ausers=explode(",",$row[$action]);
			if(in_array(login_id,$ausers)){
				return true;
			}
		}
		return false;
	}
}
function create_id($string){
	$string = preg_replace('/[^a-zA-Z0-9\s]/', '', $string);
	return(str_replace(array(" "),"_",$string));
}
function create_name($string){
	$remove=array("'",'"');
	return str_replace($remove,"",$string);
}
function systemLog($message,$table="default_log"){
	$ip=$_SERVER[REMOTE_ADDR];
	$url=$_SERVER[REQUEST_URI];
	$sql_message=trim(mysql_escape_string($message));
	if(mysql_query("INSERT INTO $table (ip,url,message) VALUES ('$ip','$url','$sql_message')")){
		echo "[LOGGED] $message <br />";
		return true;
	}
	else{
		echo "[ERROR LOG] $message <br />";
		return false;
	}
}
function format_time($seconds){
	if(!is_numeric($seconds)){return false;break;}
	$min=floor($seconds/60);
	$sec=round($seconds%60,2);
	if($sec<=9){$sec="0$sec";}
	$time="$min:$sec";
	return $time;
}
function delTree($dir) { 
    $files = glob( $dir . '*', GLOB_MARK ); 
    foreach( $files as $file ){ 
        if( substr( $file, -1 ) == '/' ) 
            delTree( $file ); 
        else 
            unlink( $file ); 
    } 
    rmdir( $dir ); 
}
function scan_dir($dir){
	$files=array();
	if(is_dir($dir)){
		$dh = opendir($dir);
		if(file_exists($dir)){
			while (($file = readdir($dh)) !== false) {
				if($file=="."){}
				elseif($file==".."){}
				else{
					$files[]=$file;
				}
			}
		}
	}
	return $files;
}
function generateNow(){
	return date("l F j, Y - h:i:s A");
}
function submap_dir($submap_name){
	$sql_submap_name=mysql_escape_string($submap_name);
	if(is_numeric($submap_name))
		$result=mysql_query("SELECT * FROM file_drives WHERE id='$sql_submap_name' LIMIT 1");
	else	
		$result=mysql_query("SELECT * FROM file_drives WHERE name='$sql_submap_name' LIMIT 1");
	while($row=mysql_fetch_array($result)){return $row['submap_dir'];}
	return false;
}
function get_drive($id){
	if(is_numeric($id)){
		$result=mysql_query("SELECT name FROM file_drives WHERE id='$id' LIMIT 1");
		while($row=mysql_fetch_array($result)){return $row['name'];break;}
		return false;
	}
	return false;
}
function get_drive_id($name){
	if(!empty($name)){
		$name=mysql_escape_string($name);
		$result=mysql_query("SELECT id FROM file_drives WHERE name='$name' LIMIT 1");
		while($row=mysql_fetch_array($result)){return $row['id'];}
		return false;
	}
	return false;
}
function convert_timestamp($stamp,$change_hour=0){
	$time = strtotime($stamp);
	$display_ts = date('g:iA n/j/Y', $time);
	if($change_hour!=0)
		$display_ts = date('Y-m-d H:i:s', $time+$change_hour*3600);
	return $display_ts;
}
function format_size($size){
	if(!is_numeric($size))
		return false;
	if($size>1000000000){$num=$size/1000000000;$num=round($num,2);$value="$num GB";}
	elseif($size>1000000){$num=$size/1000000;$num=round($num);$value="$num MB";}
	elseif($size>1000){$num=$size/1000;$num=round($num);$value="$num KB";}
	else{$value="$size B";}
	return $value;
}
function filesize2($file){
        // Return size in Mb
        clearstatcache();
        $INT = 4294967295;//2147483647+2147483647+1;
        $size = filesize($file);
        $fp = fopen($file, 'r');
        fseek($fp, 0, SEEK_END);
        if (ftell($fp)==0) $size += $INT;
        //fclose($file);
        if ($size<0) $size += $INT;
        return format_size(ceil($size));
}
function file_extension($filename){
	return strtolower(end(explode(".",$filename)));
}
function display_msg(){
	if(isset($_GET['msg'])){
		$m=$_GET['msg'];
		unset($msg);
		$error=0;
		//if(isset($_SESSION['ref'])){$msg="You must be logged in to view that page";$error=1;}
		if($m=="login_invalid"){$msg="Invalid login";$error=1;}
		if($m=="login_out"){$msg="Successfully logged Out";}
		if($m=="admin_updated"){$msg="Settings updated";}
		if($m=="admin_drive_deleted"){$msg="Drive deleted";}
		if($m=="admin_user_deleted"){$msg="User deleted";}
		if($m=="login_blank"){$msg="Login blank";$error=1;}
		if($m=="drive_none"){$msg="No such drive";$error=1;}
		if($m=="restricted_access"){$msg="You do not have permission to access this page";$error=1;}
		if($m=="path_unavailable"){$msg="The directory does not exist";$error=1;}
		if($m=="drive_unavailable"){$msg="The drive does not exist";$error=1;}
		if($m=="file_unavailable"){$msg="The file does not exist";$error=1;}
		if($m=="installed"){$msg="CloudStorage installed; Username: admin ";}
		if($m=="require_recyclebin"){$msg="You must assign a drive named recyclebin";$error=1;}
		if($m=="require_tmpdrive"){$msg="You must assign a drive named tmp";$error=1;}
		
		if($error==1){$emsg='error';$icon="cancel";}
		else{$emsg='success';$icon="accept";}
		
		if(isset($msg)){
			$message_content="<div class='message'><div class='$emsg'><div class='message_i'><img src='src/img/icons/$icon.png'><a title='close' href='#close' id='close' class='fright'><img src='src/img/icons/cross.png'></a> $msg</div></div></div>";
			echo $message_content;
		}
	}
}

function validate_username($username){
	if(!preg_match('/\W/',$username))
		return true;
	return false;	
}
function redirect($uri){
	if(isset($_GET['ajax'])){
		echo $uri;exit;
	}
	else{
		header("Location: $uri");exit;	
	}
}