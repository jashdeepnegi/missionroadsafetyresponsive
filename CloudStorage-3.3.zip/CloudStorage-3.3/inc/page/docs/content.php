<h2>Getting Started</h2>
<p>This is a rough guide on getting started with the new Cloud Storage app. After you have connected with facebook, you will automatically be give a new drive under your name. By default you will also be able to see all your friends drive (if they have added the cloud storage facebook app). For now the app is pretty simple, if it is your drive, you can edit, delete, upload files. If is your friend's drive you can only view/download their files.</p>
<p>To upload files, look for the icons of a folder with a plus symbol on the right side of your drive. From there you can create a new folder and add files inside here.</p>
<p>
Thanks again for downloading the app. If you have bug reports or suggestions please send them to admin@alvinsng.com, this is currently a beta, expect lots of new features to come!
</p>