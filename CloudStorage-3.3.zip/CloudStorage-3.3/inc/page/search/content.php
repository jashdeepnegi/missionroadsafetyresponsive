<h2><a class='button-update fright' href='javascript:run_php("?ajax=cron&option=index","search");'>Update Index</a>Search</h2>
<?php
$result = mysql_query("SELECT * FROM file_updates WHERE update_type='index' ORDER BY id DESC limit 1");
while($row=mysql_fetch_array($result))
	break;
if(!$row){
	echo "<p>Click the Update Index button on the left to use the search function. </p>";
}
else{
?>
<p> There are currently <b><?php echo $row['count'];?></b> files last indexed on <b><?php echo convert_timestamp($row['timestamp']);?></b> </p>
<div class="ui-widget">
	<input type="text" id="input_search">
</div>
<div id="search_results">
</div>
<?php
}