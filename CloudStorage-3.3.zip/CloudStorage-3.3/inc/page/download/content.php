<?php
$url = base64_decode($_GET['url']);

$drive=reset(explode("/",$url));
$submap_dir=submap_dir($drive);
$drive_len=strlen($drive);
$trail=substr($url,$drive_len+1);
if(!permission($drive,"view"))
	redirect("?msg=restricted_access");
$file_path="$submap_dir/$trail";
$exten=file_extension($file_path);
$sql_drive=mysql_escape_string($drive);
$sql_trail=mysql_escape_string($trail);
$file_name=end(explode("/",$trail));
if (!file_exists($file_path)) 
	redirect("?msg=file_unavailable");
else{
	$result=mysql_query("SELECT * FROM temp_files WHERE drive='$sql_drive' AND file='$sql_trail' ORDER BY id DESC LIMIT 1");
	$have=mysql_num_rows($result);
		while($row=mysql_fetch_array($result)){
			$download_url=$rel_up."tmp/file/$row[id]-$row[rand]/$file_name";
		}
	if($have>0&&file_exists($download_url)){
		echo "<div style='margin-top:2px;font-size:.8em'><a href=\"$download_url\" target='_blank' id='download_button'> Download Link</a> </div>";
	}
	else{
		$filesize=filesize($file_path);
		$rand=substr(sha1(rand(10000000,99999999)),0,10);
		mysql_query("INSERT INTO temp_files (file,drive,exten,rand,size) VALUES ('$sql_trail','$sql_drive','$exten','$rand','$filesize')");
		$temp_file_id=$insert_id=mysql_insert_id();
		$mkdir="tmp/file/$insert_id-$rand";
		mkdir($mkdir);
		$download_url="$mkdir/$file_name";
		$download_path="$download_url";
?>
		<div style='padding:3px'>
		<div id="progressbar"></div>
		</div>
		<script type="text/javascript">

		t=setTimeout("downloadStatus('<?php echo $temp_file_id;?>')",0);
		$("#progressbar").progressbar({
			value: 0
		});

		</script>
		<iframe style='visibility:hidden;' src='?ajax=copy&id=<?php echo $temp_file_id;?>' frameborder='0' border='0' width='0' height='0'></iframe>
<?php
	}
}