<div id="login_box">
<div id="msg_area">
<?php
display_msg();
?>
</div>
<table class='td_center'>
<tr><td><b>Username:</b></td><td> <input id="input_username" type="text" name="username"></td></tr>
<tr><td><b>Password:</b></td><td> <input id="input_password" type="password" name="password"></td></tr>
</table>
<a class="button" id="login_button" href="javascript:login();">Login</a>
</div>