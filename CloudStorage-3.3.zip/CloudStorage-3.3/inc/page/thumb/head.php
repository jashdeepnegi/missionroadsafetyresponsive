<?php
$url = base64_decode($_GET['url']);
$drive=reset(explode("/",$url));
$drive_len=strlen($drive);
$trail=substr($url,$drive_len+1);
$submap_dir=submap_dir($drive);
$file_path="$submap_dir/$trail";
$exten = file_extension($file_path);

$drive_id=get_drive_id($drive);
if(!$drive_id)
	redirect("no-drive");

$sql_trail=mysql_escape_string($trail);
$result=mysql_query("SELECT * FROM image_cache WHERE drive='$drive_id' AND trail='$sql_trail' ORDER BY id DESC LIMIT 1");
while($row=mysql_fetch_array($result)){
	$download_url="tmp/img/$row[id]-$row[hash].$exten";
	$image_path=$download_url;
}
if(mysql_num_rows($result)>0&&file_exists($image_path)){
	redirect("$download_url");
}
else{
	$rand=rand(100000000,999999999);
	$hash=sha1($rand);
	mysql_query("INSERT INTO image_cache (drive,trail,hash) VALUES ('$drive_id','$sql_trail','$hash')");
	$image_id=mysql_insert_id();
	$download_url="tmp/img/$image_id-$hash.$exten";
	smart_resize_image($file_path,$download_url);
	redirect("$download_url");
}