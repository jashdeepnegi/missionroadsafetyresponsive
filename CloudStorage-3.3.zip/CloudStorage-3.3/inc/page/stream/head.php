<?php
$url = base64_decode($_GET['url']);
$drive=reset(explode("/",$url));
if(!permission($drive,"view")){
	echo "Permission denied for drive $drive";
	exit;
}
$submap_dir=submap_dir($drive);
$drive_len=strlen($drive);
$trail=substr($url,$drive_len+1);
$file_path="$submap_dir/$trail";
$exten=file_extension($file_path);

$sql_drive=mysql_escape_string($drive);
$sql_trail=mysql_escape_string($trail);
$file_name=end(explode("/",$trail));

$have_cache=false;

$result=mysql_query("SELECT * FROM temp_files WHERE drive='$sql_drive' AND file='$sql_trail'");
if(mysql_num_rows($result)>0&&file_exists($file_path)){
	while($row=mysql_fetch_array($result)){
		$download_url="tmp/file/$row[id]-$row[rand]/$file_name";
		$download_path=$download_url;
		if(file_exists($download_path)){
			$have_cache=true;
			if($_GET['type']=="link"){
				echo "success~^~$download_url";
			}
			else{
				redirect($download_path);
			}
		}
	}
}
if($have_cache==false){
	$filesize=filesize($file_path);
	$rand=substr(sha1(rand(10000000,99999999)),0,10);
	mysql_query("INSERT INTO temp_files (file,drive,exten,rand,size) VALUES ('$sql_trail','$sql_drive','$exten','$rand','$filesize')");
	$temp_file_id=$insert_id=mysql_insert_id();
	$mkdir="tmp/file/$insert_id-$rand";
	mkdir($mkdir);
	$download_url="$mkdir/$file_name";
	$download_path="$mkdir/$file_name";
	copy($file_path,$download_path);
	if($_GET['type']=="link"){
		echo "success~^~$download_url";
	}
	else{
		redirect($download_url);exit;
	}
}