<h2>Drives</h2>
<ul class='drive_list'>
<?php
$drives=array();
$result=mysql_query("SELECT * FROM file_drives WHERE name!='recyclebin' ORDER BY name");
while($row=mysql_fetch_array($result)){
	if(permission($row['name'],"view")){
		$drives[]=$row['name'];
	}
}
if(permission("recyclebin","view")){
	$drives[]="recyclebin";
}
foreach($drives as $drive){
	$name=ucwords($drive);
	if($drive=="recyclebin"||$drive=="tmp"){
		continue;
		$name="Recycle Bin";
		echo "</ul><h2>$name</h2><ul class='drive_list'>";
	}
	echo "<li id='file_$drive'><span class='location'>$drive/</span>";
	if(permission($drive,"edit")&&$drive!="recyclebin"){
		echo "<span class='fright'><a href='javascript:create_dir(\"$drive/\",\"$drive\");'><img src='src/img/icons/folder_add.png'></a></span>";
	}
	echo "<a href='javascript:open(\"".base64_encode($drive."/")."\",\"$drive\");'>";
	echo " <img class='icon drive_icon' src='src/img/icons/drive_network.png'>";
	echo " $name</a></li> \n";
}
?>
<ul>