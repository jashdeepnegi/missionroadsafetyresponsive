<?php
$users=array();
$drives=array();
$result=mysql_query("SELECT * FROM users WHERE username!='admin' ORDER BY username");
while($row=mysql_fetch_array($result))$users[]=$row;
$result=mysql_query("SELECT * FROM file_drives ORDER BY name");
while($row=mysql_fetch_array($result))$drives[]=$row;
$actions=array("view","upload","edit");

$re=false;
$refresh=null;
if($_GET['msg']=="require_recyclebin"){
	$value_drive="value='recyclebin'";
	$value_path="value='".dirname($_SERVER['DOCUMENT_ROOT'])."/recyclebin'";
	$re=true;
}
if($_GET['msg']=="require_tmpdrive"){
	$value_drive="value='tmp'";
	$value_path="value='".dirname($_SERVER['DOCUMENT_ROOT'])."/tmp'";
	$re=true;
}
if($re)
	$refresh="<input type='hidden' name='refresh' value='1'>";

?>
<h2>Admin Panel</h2>
<div class='box'>
<h3><img class='icon' src="src/img/icons/transmit.png"> Status</h3>
<div id="site_status"></div>
</div>
<!--
<div class='box'>
<h3><img class='icon' src="src/img/icons/cog.png"> Run Tasks</h3>
<a class='button' href='javascript:run_php("?ajax=cron&option=index");'>Update Index</a>
<a class='button' href='javascript:run_php("?ajax=cron&option=music");'>Update Music</a>
<a class='button' href='javascript:run_php("?ajax=cron&option=photo");'>Update Photo</a>
<a class='button' href='javascript:run_php("?ajax=cron&option=video");'>Update Video</a>
<a class='button' href='javascript:run_php("?ajax=cron&option=purge");'>Purge Cache</a>
</div>
-->
<form class='ajaxform' action='?ajax=admin' method='POST'>
<div class='box'><h3><img class='icon' src="src/img/icons/user.png"> Users</h3>
<table class='spec_table'><tr><th>Username</th><th>Password</th><th style='width:18px'></th></tr>
<?php
foreach($users as $user){
	echo "<tr><td>$user[username]</td><td>";
	echo "<input size='20' name='password_$user[username]' type='password'>";
	echo " </td><td><a href='javascript:run_ajax(\"?ajax=admin&del_user=$user[username]\");'><img src='src/img/icons/delete.png'></a></td></tr>";
}
?>
<tr><td><input type="text" name="new_user" size="16"></td><td><input size='20' name="new_pass" type='password'></td><td></td></tr>
</table>
</div>
<div class='box'><h3><img class='icon' src="src/img/icons/drive_network.png"> Drives</h3>
<table class='spec_table'><tr><th>Name</th><th>Path</th><th>View</th><th>Upload</th><th>Edit/Delete</th><th style='width:18px'></th></tr>
<?php
foreach($drives as $drive){
	echo "<tr><td>".ucwords($drive['name'])."</td><td><input type='text' name='$drive[name]' value=\"$drive[submap_dir]\" class='input_drive_path'>";
	foreach($actions as $action){
			echo "</td><td>";
			list_permissions($drive['name'],$drive[$action],$users,$action);
	}
	echo "</td><td>";
	if($drive['name']!="tmp"&&$drive['name']!="recyclebin")
		echo "<a href='javascript:run_ajax(\"?ajax=admin&del_drive=$drive[name]\");'><img src='src/img/icons/delete.png'></a>";
	echo "</td></tr>";
}
?>
<tr><td><input type='text' name='new_drive' <?php echo $value_drive;?> size="12"></td><td><input type='text' <?php echo $value_path;?> name='new_drive_path' class='input_drive_path'></td></tr>
</table>
</div>
<?php
echo $refresh;
?>
<div class='box'><h3><img class='icon' src='src/img/icons/database_refresh.png'> Submit</h3>
<input type="submit" name='send' class='button' " value="Update">
</form>
</div>