<h2><a class='fright button-update' href='javascript:run_php("?ajax=cron&option=music","music");'>Update Music</a>
Music</h2>
<?php
$result=mysql_query("SELECT * FROM music_artists ORDER BY name");
$num_artists=mysql_num_rows($result);
	$height = min($num_artists*14+5,500);
	echo "<table><tr><td style='width:300px'><div class='box'><h3><img src='src/img/icons/ipod.png'> Artists ($num_artists)</h3><div class='media_side' style='height:$height"."px'> ";
	$current_letter=null;
	while($row = mysql_fetch_array($result)){
		if($current_letter!=substr($row['name'],0,1)){
			if($current_letter!=null){echo "</ul>";}
			$current_letter=substr($row['name'],0,1);
			echo "<h4>$current_letter</h4><ul>";
		}
		$count = mysql_num_rows(mysql_query("SELECT * FROM music_map WHERE artist_id='$row[id]'"));
		echo "<li><a href='javascript:show_media(\"music\",\"artist\",$row[id],\"$row[name]\");'>$row[name] ($count)</a></li>";;
	}
	echo "</ul></div></div>";
	
	$result=mysql_query("SELECT DISTINCT year FROM music_map");
	$years=array();
	
	while($row=mysql_fetch_array($result)){
		$count=mysql_num_rows(mysql_query("SELECT * FROM music_map WHERE year='$row[year]' ORDER BY year DESC"));
		if($row['year']>1900&&$row['year']<date('Y')+2)
			$years[$row['year']]=$count;
	}
	krsort($years);
	$num_years=count($years);
	$height = min($num_years*14+5,200);
	echo "<div class='box'><h3><img src='src/img/icons/cake.png'> Year ($num_years)</h3><div style='height:$height"."px' class='media_side'><ul>";
	foreach($years as $year => $count)
		echo "<li><a href='javascript:show_media(\"music\",\"year\",\"$year\",\"$year\");'>$year ($count)</a></li>";
	echo "</ul></div></div>";
	
	$result=mysql_query("SELECT DISTINCT genre FROM music_map");
	$genres=array();
	
	while($row=mysql_fetch_array($result)){
		$sql_genre=mysql_escape_string($row['genre']);
		$count=mysql_num_rows(mysql_query("SELECT * FROM music_map WHERE genre='$sql_genre'"));
		if($count>1)
			$genres[$row['genre']]=$count;
	}
	arsort($genres);
	$num_genres=count($genres);
	$height = min($num_genres*14+5,200);
	echo "<div class='box'><h3><img src='src/img/icons/television.png'> Genre ($num_genres)</h3><div style='height:$height"."px' class='media_side'><ul>";
	foreach($genres as $genre => $count)
		echo "<li><a href='javascript:show_media(\"music\",\"genre\",\"$genre\",\"$genre\");'>$genre ($count)</a></li>";
	echo "</ul></div></div>";
	echo "</td><td class='td_gap'></td><td><div class='box'><h3><img src='src/img/icons/music.png'> Songs <span class='title_media' id='title_music'></span></h3><div class='content_media' id='content_music'><p>Please select an artist on the left</p></div></div></td></tr></table>";