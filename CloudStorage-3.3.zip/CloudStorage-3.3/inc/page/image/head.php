<?php
$url = base64_decode($_GET['url']);
$drive=reset(explode("/",$url));
$drive_len=strlen($drive);
$trail=substr($url,$drive_len+1);
$submap_dir=submap_dir($drive);
$file_path="$submap_dir/$trail";
if(!file_exists($file_path)){
	exit;
}
else
	if(permission($drive,"view")){
		smart_resize_image($file_path,null,800,600);
	}
	else
		exit;