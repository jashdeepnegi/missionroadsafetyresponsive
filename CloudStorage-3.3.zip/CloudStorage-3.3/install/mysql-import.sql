CREATE TABLE IF NOT EXISTS `file_drives` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `submap_dir` varchar(200) NOT NULL,
  `view` varchar(500) NOT NULL,
  `upload` varchar(500) NOT NULL,
  `edit` varchar(500) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `submap_dir` (`submap_dir`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=32 ;

CREATE TABLE IF NOT EXISTS `file_map` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `path` varchar(1000) NOT NULL,
  `drive` int(3) unsigned NOT NULL,
  `title` varchar(500) NOT NULL,
  `exten` varchar(5) NOT NULL,
  `remove` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=672 ;

CREATE TABLE IF NOT EXISTS `file_updates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `count` int(10) unsigned NOT NULL,
  `update_type` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

CREATE TABLE IF NOT EXISTS `image_cache` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `drive` int(1) NOT NULL,
  `trail` varchar(1000) NOT NULL,
  `hash` varchar(200) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13372 ;

CREATE TABLE IF NOT EXISTS `music_artists` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `remove` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=37 ;

CREATE TABLE IF NOT EXISTS `music_map` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `file_id` bigint(20) unsigned NOT NULL,
  `artist_id` int(200) NOT NULL,
  `song` varchar(200) NOT NULL,
  `play_count` int(10) unsigned NOT NULL,
  `playtime` int(11) NOT NULL,
  `bitrate` int(11) NOT NULL,
  `genre` varchar(100) NOT NULL,
  `year` int(11) NOT NULL,
  `remove` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `file_id` (`file_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=41 ;

CREATE TABLE IF NOT EXISTS `temp_files` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `rand` varchar(200) NOT NULL,
  `exten` varchar(5) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `file` varchar(900) NOT NULL,
  `size` int(10) NOT NULL,
  `drive` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=972 ;

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

CREATE TABLE IF NOT EXISTS `video_map` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file_id` int(11) NOT NULL,
  `thumb_hash` varchar(16) NOT NULL,
  `title` varchar(200) NOT NULL,
  `year` int(4) NOT NULL,
  `playtime` int(11) NOT NULL,
  `bitrate` int(11) NOT NULL,
  `width` int(11) NOT NULL,
  `height` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=159 ;
