<?php
error_reporting(E_ALL);

// Start a session
session_start();

// Check for the existence of a known session variable
if ( isset($_SESSION['test_value']) ) {
} else {
  $_SESSION['test_value'] = true;
}

// Close and write session
session_write_close();



require_once('../inc/lib/core.php');
$error_msg=array();
$warning_msg=array();

$basePath = substr(dirname(__FILE__),0,-8);

function checkWriteable($path){
	$file = "$path/write_test.tmp.testing";
	if(!file_exists($path))
		mkdir($path, 0777, true);
	if(!is_dir($path))
		return false;
	if(!file_put_contents($file,"test"))
		return false;
	if(!unlink($file))
		return false;
	return true;
}

$v = reset(explode(".",phpversion()));
if($v < 5)
	$error_msg[]="You must be running PHP5 or greater.";	
if(!checkWriteable("$basePath/inc"))
	$error_msg[]="Directory <b>$basePath/inc/</b> needs to be writeable";
if(!checkWriteable("$basePath/tmp"))
	$error_msg[]="Directory <b>$basePath/tmp/</b> needs to be writeable";
if(!function_exists("imagecreatetruecolor")){
	$warning_msg[]="The GD php library needs to be installed";
}
if(!function_exists("apc_fetch")){
	$warning_msg[]="Optional: You should install the APC php lib to get loading bar for uploads.";
}
if(!function_exists("popen")){
	$warning_msg[]="The Popen function needs to be enabled";	
}
if(isset($_POST['send'])){
	$config_file="../inc/config.php";
	$default_db_host=$_POST['db_host'];
	if($_POST['agree']!="1")
		$error_msg[]="You must agree to the terms of use";
	if(empty($_POST['db_host']))
		$error_msg[]="A database host must be supplied";
	if(empty($_POST['db_username']))
		$error_msg[]="A database username must be supplied";
	if(empty($_POST['db_password']))
		$error_msg[]="A database password must be supplied";
	if(empty($_POST['db_name']))
		$error_msg[]="A database name must be supplied";
	if(empty($_POST['admin_password1']))
		$error_msg[]="An admin password must be supplied";
	elseif(empty($_POST['admin_password2']))
		$error_msg[]="A confimed admin password must be supplied";
	elseif(strlen($_POST['admin_password1'])<6)
		$error_msg[]="The admin password must be at least 6 chars in length";
	elseif($_POST['admin_password1']!=$_POST['admin_password2'])
		$error_msg[]="The two admin passwords do not match";
	if(empty($_POST['drive_recyclebin']))
		$error_msg[]="A path to the recyclebin must be supplied";
	elseif(!checkWriteable($_POST['drive_recyclebin']))
		$error_msg[]="Directory <b>".$_POST['drive_recyclebin']."</b> needs to be writeable";
	if(empty($_POST['drive_tmp']))
		$error_msg[]="A path to the tmp drive must be supplied";
	elseif(!checkWriteable($_POST['drive_tmp']))
		$error_msg[]="Directory <b>".$_POST['drive_tmp']."</b> needs to be writeable";
	if(count($error_msg)==0){
		$cont=null;
		$line[]='<?php';
		$line[]='$config_db_host="'.$_POST['db_host'].'";';
		$line[]='$config_db_username="'.$_POST['db_username'].'";';
		$line[]='$config_db_password="'.$_POST['db_password'].'";';
		$line[]='$config_db_name="'.$_POST['db_name'].'";';
		$line[]='$config_admin_password="'.$_POST['admin_password1'].'";';
		foreach($line as $l)
			$cont.="$l\n";
		$cont.='?>';
		if(!file_put_contents($config_file,$cont))
			$error_msg[]="Unable to write file <b>$config_file</b>, please check file permissions";
		else{
			include($config_file);
			if(!mysql_connect($config_db_host,$config_db_username,$config_db_password)){
				$error_msg[]="Unable to connect to MySQL database";
				unlink($config_file);
			}
			elseif(!mysql_select_db($config_db_name)){
				$error_msg[]="Database <b>$config_db_name</b> not found";
				unlink($config_file);
			}
			else{
				if(!import_mysql("mysql-import.sql")){
					$error_msg[]="MySQL database insert error. Please make sure you can create tables.";
					unlink($config_file);
				}
				else{
					$sql_recyclebin = mysql_escape_string($_POST['drive_recyclebin']);
					$sql_tmp = mysql_escape_string($_POST['drive_tmp']);
					mysql_query("INSERT INTO file_drives (name,submap_dir) VALUES ('recyclebin','$sql_recyclebin')");
					mysql_query("INSERT INTO file_drives (name,submap_dir) VALUES ('tmp','$sql_tmp')");
					chmod($config_file,0755);
					header("Location: ../index.php?page=login&msg=installed");exit;
				}
			}
		}
	}
}
else
	$_POST=null;
if(empty($default_db_host)){
	$default_db_host="localhost";
}
$gpl=nl2br(file_get_contents('gpl.txt'));
$num_errors=count($error_msg);

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
	<head>
		<title>Cloud Storage</title>
		<link rel="stylesheet" type="text/css" href="install.css">
	</head>
	<body>
	<div id="main">
<?php
echo "<h2>Intall <a href='".OFFICIAL_URL."' target='_blank'>Cloud Storage v$version_number</a></h2>";
if($num_errors>0){
	echo "<h3>$num_errors Errors</h3>";
	echo "<p>Please correct the errors below:</p>";
	foreach($error_msg as $msg)
		echo "<div class='error_msg'><b>Error:</b> $msg</div>";
}
foreach($warning_msg as $msg)
	echo "<div class='warning_msg'><b>Warning:</b> $msg</div>";
?>

<p>Fill out the form below to get your cloud storage site up and running!</p>
<form method="POST">
	<h3>MySQL Config</h3>
	<table>
	<tr><td>MySQL Database Host</td><td><input type="text" name="db_host" value="<?php echo $default_db_host;?>" /></td></tr>
	<tr><td>MySQL Database Username</td><td><input type="text" name="db_username" value="<?php echo $_POST['db_username'];?>"/></td></tr>
	<tr><td>MySQL Database Password</td><td><input type="password" name="db_password" value="<?php echo $_POST['db_password'];?>"/></td></tr>
	<tr><td>MySQL Database Name</td><td><input type="text" name="db_name" value="<?php echo $_POST['db_name'];?>"/></td></tr>
	</table>
	<h3>Admin Config</h3>
	<table>
	<tr><td>Admin Password</td><td><input type="password" name="admin_password1" value="<?php echo $_POST['admin_password1'];?>"></td></tr>
	<tr><td>Confirm Admin Password</td><td><input type="password" name="admin_password2" value="<?php echo $_POST['admin_password2'];?>"></td></tr>
	</table>
	<h3>Required Drives</h3>
	<p>Please specify the absolute path of the directory where you would like these drives to point to. These directorites must have write permissions by apache/PHP.</p>
	<p><b>Important:</b> Place drive directories where it cannot be accessed over the web.</p>
	<?php
	if(!isset($_POST['drive_recylcebin']))
		$_POST['drive_recyclebin']="$basePath/drives/recyclebin";
	if(!isset($_POST['drive_tmp']))
		$_POST['drive_tmp']="$basePath/drives/tmp";
	?>
	<table>
	<tr><td>Recycle Bin</td><td><input style="width:400px" type="text" name="drive_recyclebin" value="<?php echo $_POST['drive_recyclebin'];?>"></td></tr>
	<tr><td>Tmp Drive</td><td><input style="width:400px" type="text" name="drive_tmp" value="<?php echo $_POST['drive_tmp'];?>"></td></tr>
	</table>
	<div id="gpl_license">
	<?php echo $gpl;?>
	</div>
	<input type="checkbox" name="agree" value="1"> I agree to the terms of use.
	<input class="button" type="submit" name="send" value="Install" id="submit">
</form>
	</div>
	</body>
</html>